import requests
import sys

url = "https://discord.com/api/webhooks/1134444823194107925/-QmVCKgn8-jBjmBmg2B_xsiOhnU896zSIVAev7S5RKQzvAnWQRutJe3cqx-egbvwst_8"

data = {
    "username" : 'LEVYXNET api MANAGER'
}

data["embeds"] = [
    {
        "description" : "Username: " + sys.argv[1] + "\n Host: " + sys.argv[2] + "\n Port: " + sys.argv[3] + "\n Time: " + sys.argv[4] + "\n Method: " + sys.argv[5],
        "title" : "API BY LEVYXNET"
    }
]

result = requests.post(url, json = data)

try:
    result.raise_for_status()
except requests.exceptions.HTTPError as err:
    print(err)
else:
    print("Webhook Sent!, Code {}".format(result.status_code))